package com.example.pupil.bumm_admin;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Article;
import com.example.pupil.bumm_admin.pkgData.Database;

public class UpdateProductActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener ,View.OnClickListener{

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    Article selectedArticle;

    Database db;

    private EditText edittextName;
    private EditText edittextPreis;
    private EditText edittextBeschreibung;
    private Button   bttnUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);

        db = Database.newInstance();

        int artNr =  this.getIntent().getExtras().getInt("selectedArticle");


        try {
            selectedArticle = db.getArticle(artNr);

            initComponents();
           showArticle();
            setListener();
        } catch (Exception e) {
            //Toast.makeText(this, "Fail: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }


    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();


        if(id == R.id.restock){
            startActivity(new Intent(UpdateProductActivity.this,  RestockActivity.class));
        }
        if(id == R.id.product){
            startActivity(new Intent(UpdateProductActivity.this, ProductActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(UpdateProductActivity.this, OrdersActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(UpdateProductActivity.this, LoginActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(UpdateProductActivity.this, RatingActivity.class));
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    private void initComponents() throws Exception{
        edittextName = (EditText) findViewById(R.id.editTextName);
        edittextPreis = (EditText) findViewById(R.id.editTextPreis);
        edittextBeschreibung = (EditText) findViewById(R.id.editTextBeschreibung);
        bttnUpdate = (Button) findViewById(R.id.updateProdukt);


    }

    private void setListener() throws Exception{
        bttnUpdate.setOnClickListener(this);

    }

    private  void showArticle(){


        edittextName.setText("" + selectedArticle.getName());
        edittextPreis.setText(("" + selectedArticle.getPrice()));
        edittextBeschreibung.setText(""+selectedArticle.getDescription());

    }

    @Override
    public void onClick(View v) {

        try {
            if (v.getId() == R.id.updateProdukt) {
                selectedArticle.setName(""+edittextName.getText().toString());
                selectedArticle.setPrice(Float.parseFloat(edittextPreis.getText().toString()));
                selectedArticle.setDescription("" + edittextBeschreibung.getText().toString());
                db.updateArticle(selectedArticle);
                startActivity(new Intent(UpdateProductActivity.this, ProductActivity.class));

            }


        } catch (Exception ex) {
            Toast.makeText(this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();

        }
    }
}
