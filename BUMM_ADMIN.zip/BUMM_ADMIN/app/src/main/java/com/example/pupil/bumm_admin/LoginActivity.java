package com.example.pupil.bumm_admin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Database;
import com.example.pupil.bumm_admin.pkgData.User;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Database db;
    private Button btnLogin;
    private TextView txtUName;
    private TextView txtPW;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

         db = Database.newInstance();
        db.setURL("http://192.168.196.169:28389/");
        //db.setURL("http://192.168.1.11:28389/");
        // db.setURL("http://192.168.196.169:28389/");

        try{
            initComponents();
            setListener();
        }catch (Exception ex){
            Toast.makeText(this, "Fail: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setListener() throws Exception{
        btnLogin.setOnClickListener(this);

    }

    private void initComponents() throws Exception{
        btnLogin = (Button) findViewById(R.id.buttonLogin);

        txtUName = (TextView) findViewById(R.id.txtUName);
        txtPW=(TextView) findViewById(R.id.txtPW);
    }

    @Override
    public void onClick(View v) {
        try{
            switch(v.getId()){
                case R.id.buttonLogin:{
                    String uname= txtUName.getText().toString();
                    String pw = txtPW.getText().toString();
                    if(uname.isEmpty() || pw.isEmpty()) //toDo: better checking......
                        throw new Exception("data cant be empty");

                    User loggedUser = db.loginUser(new User(uname,pw));
                    if(loggedUser.getRole().equals("customer")){
                        Toast.makeText(this, "The Credentials are for a User : " ,Toast.LENGTH_LONG).show();
                    }else{ //admin... toDo: implement
                        Intent intent =new Intent(this, OrdersActivity.class);
                        startActivity(intent);
                    }

                    break;
                }

            }

        }catch (Exception ex){
            Toast.makeText(this, "error: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
