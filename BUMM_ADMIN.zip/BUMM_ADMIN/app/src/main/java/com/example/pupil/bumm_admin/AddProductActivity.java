package com.example.pupil.bumm_admin;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Article;
import com.example.pupil.bumm_admin.pkgData.Category;
import com.example.pupil.bumm_admin.pkgData.Database;
import com.example.pupil.bumm_admin.pkgData.Order;

import java.util.ArrayList;
import java.util.List;

public class AddProductActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener ,View.OnClickListener,AdapterView.OnItemSelectedListener{

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;


    Database db = Database.newInstance();

    private EditText edittextName;
    private EditText edittextPreis;
    private EditText edittextBeschreibung;
    private Button bttnAdd;
    private EditText edittextAnzahl;
    private Spinner spinnercatagory;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);

        try {

            initComponents();
            setListener();
            addItemsOnSpinner();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.restock) {
            startActivity(new Intent(AddProductActivity.this, RestockActivity.class));
        }
        if (id == R.id.product) {
            startActivity(new Intent(AddProductActivity.this, ProductActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(AddProductActivity.this, LoginActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(AddProductActivity.this, OrdersActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(AddProductActivity.this, RatingActivity.class));
        }
        return false;


    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void initComponents() throws Exception{
        edittextName = (EditText) findViewById(R.id.editTextProduktname);
        edittextPreis = (EditText) findViewById(R.id.editTextPreisAdd);
        edittextBeschreibung = (EditText) findViewById(R.id.editTextDescription);
        spinnercatagory = (Spinner) findViewById(R.id.spinnerCatagory);
        bttnAdd = (Button) findViewById(R.id.bttnADDProduct);
        edittextAnzahl = (EditText) findViewById(R.id.editTextAnzahl);


    }


    private void setListener() throws Exception{
        bttnAdd.setOnClickListener(this);
        spinnercatagory.setOnItemSelectedListener(this);
    }

    public void addItemsOnSpinner() {



        try {




            ArrayAdapter<Category> itemsAdapter =
                    new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.getCategorys());
            itemsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnercatagory.setAdapter(itemsAdapter);
        }catch (Exception ex){
            Toast.makeText(this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onClick(View v) {
        try {
            if (v.getId() == R.id.bttnADDProduct) {
                Article a = new Article();
                a.setDescription(edittextBeschreibung.getText().toString());
                a.setPrice(Float.parseFloat(edittextPreis.getText().toString()));
                a.setName(edittextName.getText().toString());
                a.setOnStock( Integer.parseInt(edittextAnzahl.getText().toString()));
                a.setArtCategory(String.valueOf(spinnercatagory.getSelectedItem()));
                db.addArticle(a);


            }
        } catch (Exception ex) {
            Toast.makeText(this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Category c = (Category) parent.getItemAtPosition(position);
        Toast.makeText(this, "h:" + c.toString(), Toast.LENGTH_LONG).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
