package com.example.pupil.bumm_admin.pkgData;

/**
 * Created by pupil on 6/4/18.
 */
public class OrderArticle {
    private Article orderedArticle;
    private int amount;

    public OrderArticle() {
    }

    public OrderArticle(Article orderedArticle, int amount) {
        this.orderedArticle = orderedArticle;
        this.amount = amount;
    }


    public Article getOrderedArticle() {
        return orderedArticle;
    }

    public void setOrderedArticle(Article orderedArticle) {
        this.orderedArticle = orderedArticle;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "OrderArticle{" + "orderedArticle=" + orderedArticle + ", amount=" + amount + '}';
    }
}
