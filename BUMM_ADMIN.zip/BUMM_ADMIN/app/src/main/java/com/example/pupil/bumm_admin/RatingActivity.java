package com.example.pupil.bumm_admin;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Database;
import com.example.pupil.bumm_admin.pkgData.Rating;
import com.example.pupil.bumm_admin.pkgData.RatingReport;
import com.example.pupil.bumm_admin.pkgData.User;

import java.util.ArrayList;

public class RatingActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener , AdapterView.OnItemClickListener {


    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    Database db = Database.newInstance();

    private ListView lstRatings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);


        try {

            initComponents();
            setListener();
            fillListWithEveryReport(db.getAllRatingReports());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();



        if(id == R.id.restock){
            startActivity(new Intent(RatingActivity.this,  RestockActivity.class));
        }
        if(id == R.id.product){
            startActivity(new Intent(RatingActivity.this, ProductActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(RatingActivity.this, OrdersActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(RatingActivity.this, LoginActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(RatingActivity.this, RatingActivity.class));
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void fillListWithEveryReport(ArrayList<RatingReport> reports) throws Exception {

        ArrayAdapter<RatingReport> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, reports);


        lstRatings.setAdapter(itemsAdapter);
    }
    private void initComponents() throws Exception{
        lstRatings = (ListView) findViewById(R.id.listViewRatings);


    }

    private void setListener() throws Exception{
        lstRatings.setOnItemClickListener(this);




    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        final RatingReport a =  (RatingReport) parent.getItemAtPosition(position);
        final Rating r  = a.getReportedRating();
        final User u  = r.getUserWhoRated();


        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);


        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);






        new AlertDialog.Builder(RatingActivity.this)
                .setTitle("User löschen?")
                .setView(layout)
                .setPositiveButton("User löschen",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                try {




                                    u.setStatus("deactive");
                                    db.updateUser(u);
                                    db.deleteRatingReports(a);
                                    fillListWithEveryReport(db.getAllRatingReports());



                                } catch (Exception ex) {
                                    Toast.makeText(RatingActivity.this, "melden failed:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                .setNegativeButton("ABBRECHEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();
    }
}
