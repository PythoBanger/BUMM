package com.example.pupil.bumm_admin;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Article;
import com.example.pupil.bumm_admin.pkgData.Database;

import java.util.ArrayList;

public class RestockActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener , View.OnClickListener , AdapterView.OnItemClickListener{


    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    private ListView lstRestock;

    Database db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restock);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        db = Database.newInstance();

        try{
            initComponents();
            setListener();
            fillListWithEveryRestockItem(db.getRestockItems());
        }catch (Exception ex){
            Toast.makeText(this, "Fail: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }


        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();



        if(id == R.id.restock){
            startActivity(new Intent(RestockActivity.this,  RestockActivity.class));
        }
        if(id == R.id.product){
            startActivity(new Intent(RestockActivity.this, ProductActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(RestockActivity.this, OrdersActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(RestockActivity.this, LoginActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(RestockActivity.this, RatingActivity.class));
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }

    private void setListener() throws Exception{
        lstRestock.setOnItemClickListener(this);

    }

    private void initComponents() throws Exception{
        lstRestock = (ListView) findViewById(R.id.listViewRestock);




    }

    private void fillListWithEveryRestockItem(ArrayList<Article> articles) throws Exception {
        ArrayAdapter<Article> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, articles);

        lstRestock.setAdapter(itemsAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        final Article a =  (Article) parent.getItemAtPosition(position);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText restockNr = new EditText(RestockActivity.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        restockNr.setLayoutParams(lp);
        restockNr.setInputType(InputType.TYPE_CLASS_NUMBER);

        layout.addView(restockNr);



        new AlertDialog.Builder(RestockActivity.this)
                .setTitle("Artikel auffüllen?")
                .setView(layout)
                .setPositiveButton("Finish",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                try {

                                        a.setChangeStock(Integer.parseInt(restockNr.getText().toString()));
                                        db.updateArticle(a);

                                } catch (Exception ex) {
                                    //Toast.makeText(ArticleDetailActivity.this, "melden failed:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                .setNegativeButton("ABBRECHEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();
    }
}
