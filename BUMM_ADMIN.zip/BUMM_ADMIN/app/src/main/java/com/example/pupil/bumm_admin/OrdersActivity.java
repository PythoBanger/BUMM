package com.example.pupil.bumm_admin;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Database;
import com.example.pupil.bumm_admin.pkgData.Order;
import com.example.pupil.bumm_admin.pkgData.User;

import java.util.ArrayList;

public class OrdersActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener{


    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private ListView orderView;
    private Database db;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db = Database.newInstance();

        orderView = (ListView)findViewById(R.id.orderListView);

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);

        try {
            fillListWithEveryArticle(db.getOrders());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();
        Toast.makeText(this, " order id on Nav ist  :" , Toast.LENGTH_LONG).show();


        if(id == R.id.restock){
            startActivity(new Intent(OrdersActivity.this,  RestockActivity.class));
        }
        if(id == R.id.product){
            startActivity(new Intent(OrdersActivity.this, ProductActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(OrdersActivity.this, OrdersActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(OrdersActivity.this, LoginActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(OrdersActivity.this, RatingActivity.class));
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Toast.makeText(this, " order id ist  :" , Toast.LENGTH_LONG).show();

        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void fillListWithEveryArticle(ArrayList<Order> orders) throws Exception {

        Toast.makeText(this, "eDere", Toast.LENGTH_LONG).show();
        ArrayAdapter<Order> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, orders);

        orderView.setAdapter(itemsAdapter);
    }

}
