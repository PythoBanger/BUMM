package com.example.pupil.bumm_admin;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.pupil.bumm_admin.pkgData.Article;
import com.example.pupil.bumm_admin.pkgData.Category;
import com.example.pupil.bumm_admin.pkgData.Database;

import java.util.ArrayList;

public class ProductActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener ,AdapterView.OnItemClickListener,View.OnClickListener{

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    private ListView lstProduct;
    private Button bttnAddProduct;
    private Button bttnSearch;

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        db = Database.newInstance();

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);


        try{
            initComponents();
            setListener();
            fillListWithEveryProduct(db.getArticles());
        }catch (Exception ex){
            Toast.makeText(this, "Fail: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }




        Button buttonAddProduct = (Button) findViewById(R.id.bttnAddProduct);

        buttonAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProductActivity.this, AddProductActivity.class));
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();


        if(id == R.id.restock){
            startActivity(new Intent(ProductActivity.this,  RestockActivity.class));
        }
        if (id == R.id.orders) {
            startActivity(new Intent(ProductActivity.this, OrdersActivity.class));
        }
        if(id == R.id.product){
            startActivity(new Intent(ProductActivity.this, ProductActivity.class));
        }
        if (id == R.id.logout) {
            startActivity(new Intent(ProductActivity.this, LoginActivity.class));
        }
        if (id == R.id.ratings) {
            startActivity(new Intent(ProductActivity.this, RatingActivity.class));
        }
        return false;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initComponents() throws Exception{
        lstProduct = (ListView) findViewById(R.id.lstProducts);
        bttnAddProduct = (Button) findViewById(R.id.bttnAddProduct);
        bttnSearch = (Button) findViewById(R.id.buttonSearch);


    }

    private void setListener() throws Exception{
        lstProduct.setOnItemClickListener(this);
        bttnSearch.setOnClickListener(this);
        bttnAddProduct.setOnClickListener(this);



    }

    private void fillListWithEveryProduct(ArrayList<Article> articles) throws Exception {
        ArrayAdapter<Article> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, articles);

        lstProduct.setAdapter(itemsAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        final Article a =  (Article) parent.getItemAtPosition(position);



        Intent intent = new Intent(ProductActivity.this, UpdateProductActivity.class);
        intent.putExtra("selectedArticle", a.getArtNr());
        startActivity(intent);

    }

    @Override
    public void onClick(View v) {
        try {
            if (v.getId() == R.id.bttnAddProduct) {

                startActivity(new Intent(ProductActivity.this, AddProductActivity.class));

            }
            if (v.getId() == R.id.buttonSearch) {
                LinearLayout layout = new LinearLayout(this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText artName = new EditText(ProductActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                artName.setLayoutParams(lp);
                artName.setInputType(InputType.TYPE_CLASS_TEXT);
                artName.setHint("articlename");
                layout.addView(artName);

                final Spinner allKat = new Spinner(ProductActivity.this);
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);

                allKat.setLayoutParams(lp2);
                ArrayAdapter<Category> catAdapter =
                        new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.getCategorys());
                allKat.setAdapter(catAdapter);
                layout.addView(allKat);

                new AlertDialog.Builder(ProductActivity.this)
                        .setView(layout)
                        .setTitle("ARTIKEL FILTERN")
                        .setNegativeButton("ABBRECHEN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                })
                        .setPositiveButton("FILTERN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        try {
                                            Category cat = (Category) allKat.getSelectedItem();
                                            ArrayList<Article> filteredArticles = db.filterArticles(artName.getText().toString(), cat.getCurCategory());
                                            fillListWithEveryProduct(filteredArticles);
                                            dialog.cancel();
                                        } catch (Exception ex) {
                                            Toast.makeText(ProductActivity.this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                }).show();
            }
        } catch (Exception ex) {
            Toast.makeText(this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();

        }
    }
}
