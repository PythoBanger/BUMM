package com.example.pupil.bumm_admin.pkgData;

import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

/**
 * Created by pupil on 6/4/18.
 */
public class Database {

    private static Database db=null;
    private static ControllerSync controller = null;
    private static String url = null;
    private static User curUser =null;

    private Database() {
    }

    public static Database newInstance(){
        if(db==null)
            db= new Database();
        return db;
    }

    public static User getCurUser() {
        return curUser;
    }

    public static void setCurUser(User curUser) {
        Database.curUser = curUser;
    }

    public static void setURL(String _url){
        url=_url;
    }



    //return all Orders
    public ArrayList<Order> getOrders() throws Exception{


        System.out.println("BIM In Orders");
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLORDERS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Order>>() {}.getType();
        ArrayList<Order> vec = gson.fromJson(strFromWebService, collectionType);

        System.out.println(vec.size());
        return vec;


    }

    //return all Restockitems
    public ArrayList<Article> getRestockItems() throws Exception{



        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLRESTOCKITEMS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);

        System.out.println(vec.size());
        return vec;


    }


    //return user
    public User loginUser(User u) throws Exception{


        System.out.println("Hallo login");
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "LOGINUSER";
        paras[1] = gson.toJson(u,User.class);

        controller.execute(paras);
        String strFromWebService = controller.get();
        User loggedUser=null;

        System.out.println("sfdfdfdsfds" + strFromWebService);

        try{
            System.out.println("Hallo login2");
            Type collectionType = new TypeToken<User>() {}.getType();
            loggedUser = gson.fromJson(strFromWebService, collectionType);
            System.out.println("Hallo login3");

        }catch(Exception ex) {
            throw new Exception(strFromWebService);
        }


        curUser =loggedUser;
        return loggedUser;
    }

    public String updateArticle(Article article) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strArticle = gson.toJson(article,Article.class);

        String paras[] = new String[2];
        paras[0] = "UPDATEARTICLE";
        paras[1] = strArticle;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="update ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }


}
