package com.example.pupil.bumm_admin.pkgData;

import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

/**
 * Created by pupil on 6/4/18.
 */
public class Database {

    private static Database db=null;
    private static ControllerSync controller = null;
    private static String url = null;
    private static User curUser =null;

    private Database() {
    }

    public static Database newInstance(){
        if(db==null)
            db= new Database();
        return db;
    }

    public static User getCurUser() {
        return curUser;
    }

    public static void setCurUser(User curUser) {
        Database.curUser = curUser;
    }

    public static void setURL(String _url){
        url=_url;
    }



    //return all Orders
    public ArrayList<Order> getOrders() throws Exception{


        System.out.println("BIM In Orders");
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLORDERS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Order>>() {}.getType();
        ArrayList<Order> vec = gson.fromJson(strFromWebService, collectionType);

        System.out.println(vec.size());
        return vec;


    }


}
