package com.example.pupil.bumm_admin.pkgData;

import android.widget.Toast;

import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

/**
 * Created by pupil on 6/4/18.
 */
public class Database {

    private static Database db=null;
    private static ControllerSync controller = null;
    private static String url = null;
    private static User curUser =null;

    private Database() {
    }

    public static Database newInstance(){
        if(db==null)
            db= new Database();
        return db;
    }

    public static User getCurUser() {
        return curUser;
    }

    public static void setCurUser(User curUser) {
        Database.curUser = curUser;
    }

    public static void setURL(String _url){
        url=_url;
    }



    //return all Orders
    public ArrayList<Order> getOrders() throws Exception{


        System.out.println("BIM In Orders");
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLORDERS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Order>>() {}.getType();
        ArrayList<Order> vec = gson.fromJson(strFromWebService, collectionType);

        System.out.println(vec.size());
        return vec;


    }

    //return all Restockitems
    public ArrayList<Article> getRestockItems() throws Exception{



        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLRESTOCKITEMS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);

        System.out.println(vec.size());
        return vec;


    }


    //return user
    public User loginUser(User u) throws Exception{


        System.out.println("Hallo login");
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "LOGINUSER";
        paras[1] = gson.toJson(u,User.class);

        controller.execute(paras);
        String strFromWebService = controller.get();
        User loggedUser=null;

        System.out.println("sfdfdfdsfds" + strFromWebService);

        try{
            System.out.println("Hallo login2");
            Type collectionType = new TypeToken<User>() {}.getType();
            loggedUser = gson.fromJson(strFromWebService, collectionType);
            System.out.println("Hallo login3");

        }catch(Exception ex) {
            throw new Exception(strFromWebService);
        }


        curUser =loggedUser;
        return loggedUser;
    }

    public String updateArticle(Article article) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strArticle = gson.toJson(article,Article.class);

        String paras[] = new String[2];
        paras[0] = "UPDATEARTICLE";
        paras[1] = strArticle;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="update ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public ArrayList<Article> getArticles() throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLARTICLES");
        String strFromWebService = controller.get();
        System.out.println("" + strFromWebService);
        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);

        return vec;
    }

    public Article getArticle(int artNr) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);
        String paras[] = new String[2];
        paras[0] = "GETARTICLE";
        paras[1] = ""+artNr;
        controller.execute(paras);
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<Article>() {}.getType();
        Article vec = gson.fromJson(strFromWebService, collectionType);
        if(vec==null)
            throw new Exception("no article was found....");
        return vec;
    }

    public void addArticle(Article a) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strArticle = gson.toJson(a);

        String paras[] = new String[2];
        paras[0] = "ADDARTICLE";
        paras[1] = strArticle;

        controller.execute(paras);
        String res=  controller.get();
        if(res.length()!=0)
            throw new Exception(res);

    }

    public ArrayList<Category> getCategorys() throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLCATEGORYS");
        String strFromWebService = controller.get();
        System.out.println("" + strFromWebService);
        Type collectionType = new TypeToken<ArrayList<Category>>() {}.getType();
        ArrayList<Category> vec = gson.fromJson(strFromWebService, collectionType);

        return vec;
    }

    public ArrayList<Article> filterArticles(String artName, String curCategory) throws Exception { //searches automatically in the children too
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[3];
        paras[0] = "FILTERARTICLES";
        paras[1] = artName;
        paras[2] = curCategory;
        controller.execute(paras);

        String strFromWebService = controller.get();


        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);
        return vec;

    }

    public ArrayList<RatingReport> getAllRatingReports() throws Exception {
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLRATINGSREPORTS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<RatingReport>>() {}.getType();
        ArrayList<RatingReport> rp = gson.fromJson(strFromWebService, collectionType);
        System.out.println(rp.toString());
        return rp;

    }

    public String deleteRatingReports(RatingReport rp) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "DELETEREPORT";
        paras[1] = ""+rp.getReportedRating().getRatedArticle().getArtNr()+"/"+rp.getReportedRating().getUserWhoRated().getUsername();
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="delete ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String updateUser(User user) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strUser = gson.toJson(user,User.class);

        String paras[] = new String[2];
        paras[0] = "UPDATEUSER";
        paras[1] = strUser;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="update ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }


}
