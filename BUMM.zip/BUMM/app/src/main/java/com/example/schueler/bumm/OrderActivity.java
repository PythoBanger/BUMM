package com.example.schueler.bumm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

public class OrderActivity extends AppCompatActivity implements AdapterView.OnItemLongClickListener {
        ListView ReportsListView;
        Database db=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        try {
            db = Database.newInstance();
            initComponents();
            setListener();
            fillListWithReports();
        } catch (Exception ex) {
            Toast.makeText(this, "error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void initComponents() {
        ReportsListView = (ListView) findViewById(R.id.listVReports);;

    }
    private void setListener() throws Exception{
        ReportsListView.setOnItemLongClickListener(this);
    }

    private void fillListWithReports() throws Exception {
        ArrayAdapter<RatingReport> itemsAdapter =
                new ArrayAdapter<RatingReport>(this, android.R.layout.simple_list_item_1, db.getAllRatingReports());

        ReportsListView.setAdapter(itemsAdapter);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        final Order rp = (Order) parent.getItemAtPosition(position);

        Toast.makeText(this, ""+rp.toString(), Toast.LENGTH_LONG).show();
        return true;
    }
}
