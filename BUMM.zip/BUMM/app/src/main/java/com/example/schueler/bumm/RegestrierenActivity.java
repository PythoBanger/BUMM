package com.example.schueler.bumm;

import java.text.*;
import java.util.*;

import android.content.*;
import android.support.design.widget.*;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import com.example.schueler.bumm.pkgData.*;

public class RegestrierenActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btnRegister;
    private TextView txtVorname;
    private TextView txtNachname;
    private TextView txtPW;
    private TextView txtUName;
    private TextView txtStrasse, txtOrt, txtPlz, txtEmail, txtGebDate;
    private NavigationView nv;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regestrieren);
        try{
            initComponents();
            setListener();
        }catch (Exception ex){
            Toast.makeText(this,"Fail: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }


    private void setListener() {
        btnRegister.setOnClickListener(this);
    }

    private void initComponents() {
        db = Database.newInstance();
        btnRegister = (Button) findViewById(R.id.buttonRegister);
        txtVorname = (TextView) findViewById(R.id.editTextVorname);
        txtNachname = (TextView) findViewById(R.id.editTextNachname);
        txtPW = (TextView) findViewById(R.id.editTextPW);
        txtUName= (TextView) findViewById(R.id.editTextUN);
        txtOrt=(TextView) findViewById(R.id.editTextOrt);
        txtStrasse=(TextView) findViewById(R.id.editTextStraße);
        txtPlz = (TextView) findViewById(R.id.editTextPlz);
        txtEmail=(TextView) findViewById(R.id.editTextEmail);
        txtGebDate=(TextView) findViewById(R.id.editTextDate);
    }


    @Override
    public void onClick(View view) {
        try{
            switch(view.getId()){
                case R.id.buttonRegister:{
                    SimpleDateFormat sdf = new SimpleDateFormat("dd.mm.yyyy");
                    Date d=sdf.parse(txtGebDate.getText().toString());
                    String [] date = (txtGebDate.getText().toString().split("\\."));
                    int day = Integer.parseInt(date[0]); //toDo: make it better
                    int month = Integer.parseInt(date[1]);
                    int year = Integer.parseInt(date[2]);
                    String vn= txtVorname.getText().toString();
                    String nn= txtNachname.getText().toString();
                    String un= txtUName.getText().toString();
                    String pw= txtPW.getText().toString();
                    String strase= txtStrasse.getText().toString();
                    String ort= txtOrt.getText().toString();
                    String email= txtEmail.getText().toString();
                    int plz= Integer.parseInt(txtPlz.getText().toString());

                    //toDo: better daat checking
                    if(vn.isEmpty() || nn.isEmpty() || un.isEmpty() || pw.length()<5 || strase.isEmpty() || ort.isEmpty() || email.isEmpty() || plz<0)
                        throw new Exception("invalid register data");

                    User u = new User(un,pw,vn,nn,email,ort,strase,"customer",new LocalDate(day,month,year),plz,"active");
                    String res = db.addUser(u);
                    Toast.makeText(this, "" + res,Toast.LENGTH_LONG).show();
                    Intent intent= new Intent(this, LoginActivity.class);
                    startActivity(intent);
                    break;
                }
            }

        }catch (Exception ex){
            Toast.makeText(this, "error: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

}
