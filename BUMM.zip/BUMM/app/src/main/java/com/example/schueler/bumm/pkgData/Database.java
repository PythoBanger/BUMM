package com.example.schueler.bumm.pkgData;

import java.lang.reflect.*;
import java.util.*;

import com.example.schueler.bumm.pkgMisc.*;
import com.google.gson.*;
import com.google.gson.reflect.*;

public class Database {
    private static Database db=null;
    private static ControllerSync controller = null;
    private static String url = null;
    private static User curUser =null;

    private Database() {
    }

    public static Database newInstance(){
        if(db==null)
            db= new Database();
        return db;
    }

    public static User getCurUser() {
        return curUser;
    }

    public static void setCurUser(User curUser) {
        Database.curUser = curUser;
    }

    public static void setURL(String _url){
        url=_url;
    }

    //return all customers (for admin only)
    public ArrayList<User> getUsers() throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLUSERS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<User>>() {}.getType();
        ArrayList<User> vec = gson.fromJson(strFromWebService, collectionType);

        return vec;
    }


    public User loginUser(User u) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "LOGINUSER";
        paras[1] = gson.toJson(u,User.class);

        controller.execute(paras);
        String strFromWebService = controller.get();
        User loggedUser=null;

        try{
            Type collectionType = new TypeToken<User>() {}.getType();
            loggedUser = gson.fromJson(strFromWebService, collectionType);

        }catch(Exception ex) {
            throw new Exception(strFromWebService);
        }
        if(!loggedUser.getStatus().equals("active"))
            throw new Exception("your account is currenty disabled!");

        curUser =loggedUser;
        return loggedUser;
    }

    public String addUser(User user) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strUser = gson.toJson(user,User.class);

        String paras[] = new String[2];
        paras[0] = "ADDUSER";
        paras[1] = strUser;
        controller.execute(paras);
        String res=  controller.get();
        System.out.println(""+res);
        if(res.length()==0){
            res="register ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String updateUser(User user) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strUser = gson.toJson(user,User.class);

        String paras[] = new String[2];
        paras[0] = "UPDATEUSER";
        paras[1] = strUser;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="update ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public ArrayList<Article> getArticles() throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLARTICLES");
        String strFromWebService = controller.get();
        System.out.println(""+strFromWebService);
        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);

        return vec;
    }

    public Article getArticle(int artNr) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);
        String paras[] = new String[2];
        paras[0] = "GETARTICLE";
        paras[1] = ""+artNr;
        controller.execute(paras);
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<Article>() {}.getType();
        Article vec = gson.fromJson(strFromWebService, collectionType);
        if(vec==null)
            throw new Exception("no article was found....");
        return vec;
    }

    public ArrayList<Category> getCategories() throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLCATEGORIES");
        String strFromWebService = controller.get();
        System.out.println(""+strFromWebService);
        Type collectionType = new TypeToken<ArrayList<Category>>() {}.getType();
        ArrayList<Category> vec = gson.fromJson(strFromWebService, collectionType);

        return vec;
    }

    public ArrayList<Article> filterArticles(String artName, String curCategory) throws Exception { //searches automatically in the children too
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[3];
        paras[0] = "FILTERARTICLES";
        paras[1] = artName;
        paras[2] = curCategory;
        controller.execute(paras);

        String strFromWebService = controller.get();


        Type collectionType = new TypeToken<ArrayList<Article>>() {}.getType();
        ArrayList<Article> vec = gson.fromJson(strFromWebService, collectionType);
        return vec;

    }


    public ArrayList<Rating> getRatingOfArticle(int artNr) throws Exception {
        Gson gson = new Gson();
        controller = new ControllerSync(url);
        String paras[] = new String[2];
        paras[0] = "GETRATINGSOFARTICLE";
        paras[1] = ""+artNr;
        controller.execute(paras);
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<Rating>>() {}.getType();
        ArrayList<Rating> vec = gson.fromJson(strFromWebService, collectionType);
        return  vec;

    }
    //change
    public String addRating(Rating r) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strUser = gson.toJson(r);

        String paras[] = new String[2];
        paras[0] = "ADDRATING";
        paras[1] = strUser;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="add ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String  updateRating(Rating r) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strRating = gson.toJson(r);

        String paras[] = new String[2];
        paras[0] = "UPDATERATING";
        paras[1] = strRating;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="update ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    //semi prof: bc post (delete request does not work) ask org
    public String deleteRating(Rating r) throws Exception {
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strRating = gson.toJson(r);

        String paras[] = new String[2];
        paras[0] = "DELETERATING";
        paras[1] = ""+r.getRatedArticle().getArtNr()+"/"+r.getUserWhoRated().getUsername();
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="delete ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String addArticleToList(String username, Article article) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strArticle = gson.toJson(article);

        String paras[] = new String[3];
        paras[0] = "ADDARTICLETOLIST";
        paras[1] = strArticle;
        paras[2]= username;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="add ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String deleteArticleFromList(String username, Article article) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "DELETEARTICLEFROMLIST";
        paras[1] = ""+article.getArtNr()+"/"+username;
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="delete ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public ArrayList<Article> getShoppingListOfUser(User curUsername) throws Exception {
        Gson gson = new Gson();
        controller = new ControllerSync(url);
        String paras[] = new String[2];
        paras[0] = "GETSHOPPINGLISTOFUSER";
        paras[1] = ""+curUsername.getUsername();

        controller.execute(paras);
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ShoppingList>() {}.getType();
        ShoppingList sl = gson.fromJson(strFromWebService, collectionType);
        db.curUser.setShoppingList(sl);
        return sl.getArticlesInList();
    }



    public ArrayList<RatingReport> getAllRatingReports() throws Exception {
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        controller.execute("GETALLRATINGSREPORTS");
        String strFromWebService = controller.get();
        Type collectionType = new TypeToken<ArrayList<RatingReport>>() {}.getType();
        ArrayList<RatingReport> rp = gson.fromJson(strFromWebService, collectionType);
        return rp;

    }

    public String deleteRatingReports(RatingReport rp) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String paras[] = new String[2];
        paras[0] = "DELETEREPORT";
        paras[1] = ""+rp.getReportedRating().getRatedArticle().getArtNr()+"/"+rp.getReportedRating().getUserWhoRated().getUsername();
        controller.execute(paras);
        String res=  controller.get();
        if(res.length()==0){
            res="delete ok";
        }else {
            throw new Exception(res);
        }
        return res;
    }

    public String addRatingReport(RatingReport rp) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strRatingReport = gson.toJson(rp);

        String paras[] = new String[2];
        paras[0] = "ADDREPORT";
        paras[1] = strRatingReport;

        controller.execute(paras);
        String res=  controller.get();
         if(res.length()==0){
            res="add ok";
        }else {
            throw new Exception(res);
        }
        return "";
    }

    public void addOrder(Order o) throws Exception{
        Gson gson = new Gson();
        controller = new ControllerSync(url);

        String strOrder = gson.toJson(o);

        String paras[] = new String[2];
        paras[0] = "ADDORDER";
        paras[1] = strOrder;

        controller.execute(paras);
        String res=  controller.get();
        if(res.length()!=0)
            throw new Exception(res);

    }

}
