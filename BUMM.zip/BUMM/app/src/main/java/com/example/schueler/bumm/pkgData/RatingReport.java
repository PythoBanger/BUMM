package com.example.schueler.bumm.pkgData;

public class RatingReport {
    private Rating reportedRating;
    private User userWhoReported;
    private LocalDate reportDate;

    public RatingReport() {

    }

    public RatingReport(Rating reportedRating, User userWhoReported, LocalDate reportDate) {
        this.reportedRating = reportedRating;
        this.userWhoReported = userWhoReported;
        this.reportDate = reportDate;
    }

    public Rating getReportedRating() {
        return reportedRating;
    }

    public void setReportedRating(Rating reportedRating) {
        this.reportedRating = reportedRating;
    }

    public User getUserWhoReported() {
        return userWhoReported;
    }

    public void setUserWhoReported(User userWhoReported) {
        this.userWhoReported = userWhoReported;
    }

    public LocalDate getReportDate() {
        return reportDate;
    }

    public void setReportDate(LocalDate reportDate) {
        this.reportDate = reportDate;
    }

    @Override
    public String toString() {
        return userWhoReported.getUsername() + " reported " + reportedRating.getUserWhoRated().getUsername() +" bc: " + reportedRating.getRatingComment();
    }






}
