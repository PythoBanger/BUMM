package com.example.schueler.bumm;

import android.content.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

public class AccountActivity extends AppCompatActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {

    private Database db;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView navigationView;
    private Button btnSave;
    private TextView txtVorname;
    private TextView txtNachname;
    private TextView txtPW,txtPWWH;
    private TextView txtStrasse, txtOrt, txtPlz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        initComponents();
        setListener();
    }

    private void setListener() {
        btnSave.setOnClickListener(this);
        mDrawerLayout.addDrawerListener(mToggle);
        navigationView.setNavigationItemSelectedListener(this);

    }

    private void initComponents() {
        db= Database.newInstance();
        mDrawerLayout =(DrawerLayout) findViewById(R.id.drawer);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        btnSave = (Button) findViewById(R.id.buttonSpeichern);
        txtVorname = (TextView) findViewById(R.id.editTextVorname);
        txtNachname = (TextView) findViewById(R.id.editTextNachname);
        txtPW = (TextView) findViewById(R.id.editTextPW);
        txtPWWH = (TextView) findViewById(R.id.editTextPWWH);
        txtOrt=(TextView) findViewById(R.id.editTextOrt);
        txtStrasse=(TextView) findViewById(R.id.editTextStraße);
        txtPlz = (TextView) findViewById(R.id.editTextPlz);

        mToggle= new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        this.setTitle(db.getCurUser().getUsername());
        User cc = db.getCurUser();
        txtVorname.setText(""+cc.getFirstName());
        txtNachname.setText(""+cc.getLastName());
        txtOrt.setText(""+cc.getLocation());
        txtPlz.setText(""+cc.getZipCode());
        txtStrasse.setText(""+cc.getAddress());
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        try{
            switch (item.getItemId()){
                case R.id.homepage:{
                    startActivity(new Intent(AccountActivity.this, HomepageActivity.class));
                    break;
                }
                case R.id.logout:{
                    Intent intent= new Intent(this, LoginActivity.class);
                    startActivity(intent);
                    break;
                }
                case R.id.meinKonto:{
                    startActivity(new Intent(AccountActivity.this, AccountActivity.class));
                    break;
                }
                case R.id.warenkorb:{
                    startActivity(new Intent(AccountActivity.this, ShoppingListActivity.class));
                    break;
                }
                case R.id.meineBestellungen:{
                   // startActivity(new Intent(KontoActivity.this, BestellungenActivity.class));
                    break;
                }

                default: {
                    Toast.makeText(this," Nothing selected in the menu!!",Toast.LENGTH_LONG).show();
                    break;
                }
            }

        }catch (Exception ex){
            Toast.makeText(this,"Error caused by Menu: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }

        return false;
    }

    @Override
    public void onClick(View view) {
        try{
            switch(view.getId()){
                case R.id.buttonSpeichern:{
                    User cc = db.getCurUser();
                    String un= cc.getUsername().toString();
                    String pw = txtPW.getText().toString();
                    String vn=  txtVorname.getText().toString();
                    String nn= txtNachname.getText().toString();
                    String strase = txtStrasse.getText().toString();
                    String email = cc.getEmail();
                    String ort = txtOrt.getText().toString();
                    LocalDate bday =  cc.getBirthdate();
                    int plz = Integer.parseInt(txtPlz.getText().toString());

                    if(vn.isEmpty() || nn.isEmpty() || un.isEmpty() || pw.length()<5 || !(pw.equals(txtPWWH.getText().toString())) || strase.isEmpty() || ort.isEmpty() || email.isEmpty() || plz<0)
                        throw new Exception("invalid register data");

                    User u = new User(un,pw,vn,nn,email,ort,strase,"customer",bday,plz,"active");
                    String erg = db.updateUser(u);
                    db.setCurUser(u);
                    Toast.makeText(this, ""+erg,Toast.LENGTH_LONG).show();
                    Intent intent= new Intent(this, HomepageActivity.class);
                    startActivity(intent);
                    break;
                }
            }
        }catch(Exception ex){
            Toast.makeText(this, "Error by click on button: " + ex.getMessage(),Toast.LENGTH_LONG).show();

        }
}}
