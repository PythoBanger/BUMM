package com.example.schueler.bumm;

import android.annotation.*;
import android.content.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

import java.util.*;

public class ArticleDetailActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemLongClickListener, View.OnClickListener {

    private Database db;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView navigationView;
    Button btn, btn2;
    TextView name,preis,onStock,descr;
    ListView listRatings;
    Article selected=null;
    int artNr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_detail);

        try{
            initComponents();
            setListener();
            showProduct();
        }catch (Exception ex){
            ex.printStackTrace();
            Toast.makeText(this,"error while creating: "+ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showProduct() throws Exception{
        artNr =  this.getIntent().getExtras().getInt("selectedProduct");
        selected = db.getArticle(artNr);
        initComponents();
        name.setText("name: "+selected.getName());
        preis.setText("price: "+selected.getPrice());
        onStock.setText("on stock: "+selected.getOnStock());
        descr.setText("description"+selected.getDescription());

      }



    private void setListener() throws Exception {
        mDrawerLayout.addDrawerListener(mToggle);
        navigationView.setNavigationItemSelectedListener(this);

        showProduct();
    }

    private void initComponents() throws Exception {
        db= Database.newInstance();
        name = (TextView) findViewById(R.id.textView);
        preis = (TextView) findViewById(R.id.textView2);
        onStock = (TextView) findViewById(R.id.textView3);
        descr = (TextView) findViewById(R.id.textView4);
        listRatings = (ListView) findViewById(R.id.lView);
        btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(this);
        btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(this);

        listRatings.setOnItemLongClickListener(this);
        ArrayList<Rating> allRatings = db.getRatingOfArticle(artNr);
        fillList(allRatings);
        mDrawerLayout =(DrawerLayout) findViewById(R.id.drawer);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        mToggle= new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        try{
            int id = item.getItemId();

            if(id == R.id.homepage){
                startActivity(new Intent(ArticleDetailActivity.this, HomepageActivity.class));
            }
            if(id == R.id.logout){
                Intent intent= new Intent(this, LoginActivity.class);
                startActivity(intent);
            }
            if(id == R.id.meinKonto){
                startActivity(new Intent(ArticleDetailActivity.this, AccountActivity.class));
            }
            if(id == R.id.warenkorb){
                startActivity(new Intent(ArticleDetailActivity.this, ShoppingListActivity.class));
            }
            if(id == R.id.meineBestellungen){
                //startActivity(new Intent(ArticleDetailActivity.this, BestellungenActivity.class));
            }
        }catch(Exception ex){
            Toast.makeText(this,"Error caused by Menu: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }

        return false;
    }


    private void fillList(ArrayList<Rating> allRatings) throws Exception {
        ArrayAdapter<Rating> adapterArticles = new ArrayAdapter<Rating>(
                this,
                android.R.layout.simple_expandable_list_item_1, allRatings);
        listRatings.setAdapter(adapterArticles);

    }


    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        final Rating a = (Rating) parent.getItemAtPosition(position);
        if(!(a.getUserWhoRated().getUsername().equals(db.getCurUser().getUsername()))){
            new AlertDialog.Builder(ArticleDetailActivity.this)
                    .setTitle("Artikel melden?")
                    .setPositiveButton("MELDEN",
                            new DialogInterface.OnClickListener() {
                                @TargetApi(11)
                                public void onClick(DialogInterface dialog, int id) {
                                    try {
                                       // String erg = db.addArticleToList(db.getCurUser().getUsername(),a);
                                        Toast.makeText(ArticleDetailActivity.this, "in development", Toast.LENGTH_LONG).show();
                                        dialog.cancel();
                                    } catch (Exception ex) {
                                        Toast.makeText(ArticleDetailActivity.this, "melden failed:" + ex, Toast.LENGTH_LONG).show();
                                    }
                                }
                            })
                    .setNegativeButton("ABBRECHEN",
                            new DialogInterface.OnClickListener() {
                                @TargetApi(11)
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            }).show();
        } else{

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);

            final EditText ratingV = new EditText(ArticleDetailActivity.this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            ratingV.setLayoutParams(lp);
            ratingV.setInputType(InputType.TYPE_CLASS_NUMBER);
            ratingV.setText(""+a.getRatingValue());
            layout.addView(ratingV);

            final EditText ratingK = new EditText(ArticleDetailActivity.this);
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            ratingK.setLayoutParams(lp2);
            ratingK.setInputType(InputType.TYPE_CLASS_TEXT);
            ratingK.setText(a.getRatingComment());
            layout.addView(ratingK);

            new AlertDialog.Builder(ArticleDetailActivity.this)
                    .setView(layout)
                    .setTitle("Deine Bewertung")
                    .setPositiveButton("LÖSCHEN",
                            new DialogInterface.OnClickListener() {
                                @TargetApi(11)
                                public void onClick(DialogInterface dialog, int id) {
                                    try{
                                        // Toast.makeText(ArticleDetail.this,"still in development",Toast.LENGTH_LONG).show();
                                        String erg = db.deleteRating(a);
                                        Toast.makeText(ArticleDetailActivity.this,""+erg,Toast.LENGTH_LONG).show();
                                        fillList(db.getRatingOfArticle(artNr));
                                        dialog.cancel();
                                    }catch (Exception ex){
                                        Toast.makeText(ArticleDetailActivity.this,"update failed:" +ex,Toast.LENGTH_LONG).show();
                                    }
                                }
                            })
                    .setNeutralButton("UPDATEN",
                            new DialogInterface.OnClickListener() {
                                @TargetApi(11)
                                public void onClick(DialogInterface dialog, int id) {
                                    try{
                                        int val= Integer.parseInt(ratingV.getText().toString());
                                        if(val<1 || val > 5)
                                            throw new Exception("value has to be between 1-5");
                                        String komment = ratingK.getText().toString();
                                        if(komment.length()<10)
                                            throw new Exception("comment has to be higher than 10 characters");

                                        a.setRatingValue(val);
                                        a.setRatingComment(komment);
                                        String erg = db.updateRating(a);
                                        Toast.makeText(ArticleDetailActivity.this,""+erg,Toast.LENGTH_LONG).show();
                                        fillList(db.getRatingOfArticle(artNr));
                                        dialog.cancel();
                                    }catch (Exception ex){
                                        Toast.makeText(ArticleDetailActivity.this,"update failed:" +ex,Toast.LENGTH_LONG).show();
                                    }
                                }
                            })
                    .setNegativeButton("ABBRECHEN",
                            new DialogInterface.OnClickListener() {
                                @TargetApi(11)
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            }).show();
        }

        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onClick(View v) {
        try{
            if(v.getId()==R.id.button){
                String erg = db.addArticleToList(db.getCurUser().getUsername(),selected);
                Toast.makeText(ArticleDetailActivity.this, "" + erg, Toast.LENGTH_LONG).show();
            }else if(v.getId()==R.id.button2){

                LinearLayout layout = new LinearLayout(this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText ratingV = new EditText(ArticleDetailActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                ratingV.setLayoutParams(lp);
                ratingV.setInputType(InputType.TYPE_CLASS_NUMBER);
                ratingV.setHint("value");
                layout.addView(ratingV);

                final EditText ratingK = new EditText(ArticleDetailActivity.this);
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                ratingK.setLayoutParams(lp2);
                ratingK.setInputType(InputType.TYPE_CLASS_TEXT);
                ratingK.setHint("comment");
                layout.addView(ratingK);

                new AlertDialog.Builder(ArticleDetailActivity.this)
                        .setView(layout)
                        .setTitle("Neue Bewertung")
                        .setPositiveButton("ADDEN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        try{
                                            int val= Integer.parseInt(ratingV.getText().toString());
                                            if(val<1 || val > 5)
                                                throw new Exception("value has to be between 1-5");
                                            String komment = ratingK.getText().toString();
                                            if(komment.length()<10)
                                                throw new Exception("comment has to be higher than 10 characters");

                                            String erg = db.addRating(new Rating(selected,db.getCurUser(),null,komment,val));
                                            Toast.makeText(ArticleDetailActivity.this,""+erg,Toast.LENGTH_LONG).show();
                                            fillList(db.getRatingOfArticle(selected.getArtNr()));
                                            dialog.cancel();
                                        }catch (Exception ex){
                                            Toast.makeText(ArticleDetailActivity.this,"update failed:" +ex,Toast.LENGTH_LONG).show();
                                        }
                                    }
                                })
                        .setNegativeButton("ABBRECHEN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                }).show();


            }
        }catch(Exception ex) {
            Toast.makeText(this,"error:" +ex.getMessage(),Toast.LENGTH_LONG).show();

        }


    }
}
