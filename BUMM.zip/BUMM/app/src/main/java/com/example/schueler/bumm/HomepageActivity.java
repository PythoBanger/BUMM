package com.example.schueler.bumm;

import android.annotation.*;
import android.content.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

import java.util.*;

public class HomepageActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, OnClickListener, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {

    private Database db;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private ListView ProductListView;
    private NavigationView navigationView;
    private Button filterBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        try {
            initComponents();
            setListener();
            fillListWithEveryArticle(db.getArticles());
        } catch (Exception ex) {
            Toast.makeText(this, "error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setListener() throws Exception{
        mDrawerLayout.addDrawerListener(mToggle);
        navigationView.setNavigationItemSelectedListener(this);
        filterBtn.setOnClickListener(this);
        ProductListView.setOnItemClickListener(this);
        ProductListView.setOnItemLongClickListener(this);
    }

    @Override
    public void onClick(View v) {
        try {
            if (v.getId() == R.id.button3) {
                LinearLayout layout = new LinearLayout(this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText artName = new EditText(HomepageActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                artName.setLayoutParams(lp);
                artName.setInputType(InputType.TYPE_CLASS_TEXT);
                artName.setHint("articlename");
                layout.addView(artName);

                final Spinner allKat = new Spinner(HomepageActivity.this);
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);

                allKat.setLayoutParams(lp2);
                ArrayAdapter<Category> catAdapter =
                        new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.getCategories());
                allKat.setAdapter(catAdapter);
                layout.addView(allKat);

                new AlertDialog.Builder(HomepageActivity.this)
                        .setView(layout)
                        .setTitle("ARTIKEL FILTERN")
                        .setNegativeButton("ABBRECHEN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                })
                        .setPositiveButton("FILTERN",
                                new DialogInterface.OnClickListener() {
                                    @TargetApi(11)
                                    public void onClick(DialogInterface dialog, int id) {
                                        try {
                                            Category cat = (Category) allKat.getSelectedItem();
                                            ArrayList<Article> filteredArticles = db.filterArticles(artName.getText().toString(), cat.getCurCategory());
                                            fillListWithEveryArticle(filteredArticles);
                                            dialog.cancel();
                                        } catch (Exception ex) {
                                            Toast.makeText(HomepageActivity.this, "error:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                }).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "error:" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        try {
            Article a = (Article) parent.getItemAtPosition(position);

            Intent intent = new Intent(HomepageActivity.this, ArticleDetailActivity.class);
            intent.putExtra("selectedProduct", a.getArtNr());
            startActivity(intent);

        } catch (Exception ex) {
            Toast.makeText(HomepageActivity.this, "error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        final Article a = (Article) parent.getItemAtPosition(position);
        new AlertDialog.Builder(HomepageActivity.this)
                .setTitle("Artikel zu deiner Liste hinzufügen?")
                .setPositiveButton("HINZUFÜGEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                try {
                                    String erg = db.addArticleToList(db.getCurUser().getUsername(),a);
                                    Toast.makeText(HomepageActivity.this, "" + erg, Toast.LENGTH_LONG).show();
                                    dialog.cancel();
                                } catch (Exception ex) {
                                    Toast.makeText(HomepageActivity.this, "adden failed:" + ex, Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                .setNegativeButton("ABBRECHEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();


        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }


    private void initComponents() {
        db = Database.newInstance();
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        ProductListView = (ListView) findViewById(R.id.listView);
        filterBtn = (Button) findViewById(R.id.button3);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void fillListWithEveryArticle(ArrayList<Article> articles) throws Exception {
        ArrayAdapter<Article> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, articles);

        ProductListView.setAdapter(itemsAdapter);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        try {
            switch (item.getItemId()) {
                case R.id.homepage: {
                    startActivity(new Intent(HomepageActivity.this, HomepageActivity.class));
                    break;
                }
                case R.id.logout: {
                    Intent intent = new Intent(this, LoginActivity.class);
                    startActivity(intent);
                    break;
                }
                case R.id.meinKonto: {
                    startActivity(new Intent(HomepageActivity.this, AccountActivity.class));
                    break;
                }
                case R.id.warenkorb: {
                    startActivity(new Intent(HomepageActivity.this, ShoppingListActivity.class));
                    break;
                }

                case R.id.meineBestellungen: {
                      startActivity(new Intent(HomepageActivity.this, OrderActivity.class));
                    break;
                }

                default: {
                    Toast.makeText(this, " Nothing selected in the menu!!", Toast.LENGTH_LONG).show();
                    break;
                }
            }

        } catch (Exception ex) {
            Toast.makeText(this, "Error caused by Menu: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        return false;
    }
}
