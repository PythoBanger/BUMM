package com.example.schueler.bumm.pkgData;

import java.io.*;
import java.util.*;

public class Order implements Serializable{
    private int orderId;
    private User userWhoOrdered;
    private ArrayList<OrderArticle> allOrderesArticles = new ArrayList<>();
    public Order() {
    }

    public Order(User userWhoOrdered) {
        this(-99,userWhoOrdered);
    }

    public Order(int orderId, User userWhoOrdered) {
        this.orderId = orderId;
        this.userWhoOrdered = userWhoOrdered;
    }


    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public User getUserWhoOrdered() {
        return userWhoOrdered;
    }

    public void setUserWhoOrdered(User userWhoOrdered) {
        this.userWhoOrdered = userWhoOrdered;
    }

    public ArrayList<OrderArticle> getAllOrderesArticles() {
        return allOrderesArticles;
    }

    public void setAllOrderesArticles(ArrayList<OrderArticle> allOrderesArticles) {
        this.allOrderesArticles = allOrderesArticles;
    }

    @Override
    public String toString() {
        return "Order{" + "orderId=" + orderId + ", userWhoOrdered=" + userWhoOrdered + ", allOrderesArticles=" + allOrderesArticles + '}';
    }

}
