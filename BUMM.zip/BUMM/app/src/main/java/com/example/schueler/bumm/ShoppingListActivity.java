package com.example.schueler.bumm;

import android.content.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.os.Bundle;
import android.util.*;
import android.view.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

import java.util.*;

public class ShoppingListActivity extends AppCompatActivity implements View.OnClickListener , AdapterView.OnItemClickListener,  NavigationView.OnNavigationItemSelectedListener{

    Database db;
    TextView twListTitle;
    Button btnBestellen, btnLöschen;
    ListView lvArticle;
    ArrayList<Article> allSelArticles= new ArrayList<>();
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);
        try {
            initComponents();
            setListener();

            mDrawerLayout =(DrawerLayout) findViewById(R.id.drawer);
            mToggle= new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
            mDrawerLayout.addDrawerListener(mToggle);
            mToggle.syncState();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            NavigationView navigationView = (NavigationView) findViewById(R.id.navigation);
            navigationView.setNavigationItemSelectedListener(this);
        } catch (Exception ex) {
            Toast.makeText(this, "Fail: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setListener() throws Exception{
        btnBestellen.setOnClickListener(this);
        btnLöschen.setOnClickListener(this);
        ArrayList<Article> allArticlesOfUser =  db.getShoppingListOfUser(db.getCurUser());
        fillListWithEveryArticle(allArticlesOfUser);
    }

    private void initComponents() throws Exception {
        db = Database.newInstance();
        twListTitle = (TextView) findViewById(R.id.textView3);
        btnBestellen = (Button) findViewById(R.id.btnBestellen);
        lvArticle = (ListView) findViewById(R.id.userList);
        btnLöschen = (Button) findViewById(R.id.btnDelete);
        twListTitle.setText(twListTitle.getText().toString()+" " + db.getCurUser().getUsername());
        lvArticle.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lvArticle.setItemChecked(2, true);
        lvArticle.setOnItemClickListener(this);


    }


    private void fillListWithEveryArticle(ArrayList<Article> articles) throws Exception {
        ArrayAdapter<Article> itemsAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, articles);

        lvArticle.setAdapter(itemsAdapter);
    }


    @Override
    public void onClick(View v) {
        try{
            if(v.getId()==R.id.btnBestellen){
                Toast.makeText(this,"in development",Toast.LENGTH_LONG).show();
            }else if(v.getId()==R.id.btnDelete){
                String username = db.getCurUser().getUsername();
                for(Article a : allSelArticles){
                    db.deleteArticleFromList(username,a);
                }
                fillListWithEveryArticle(db.getShoppingListOfUser(db.getCurUser()));
            }

        }catch (Exception ex){
            Toast.makeText(this,"Fail: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        allSelArticles = new ArrayList<>();
        SparseBooleanArray selectedCars = lvArticle.getCheckedItemPositions();
        for (int i = 0; i < selectedCars.size(); i++)
            if (selectedCars.valueAt(i)) {
                Article car = (Article) lvArticle.getAdapter().getItem(selectedCars.keyAt(i));
                allSelArticles.add(car);
            }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        try{
            int id = item.getItemId();

            if(id == R.id.homepage){
                startActivity(new Intent(ShoppingListActivity.this, HomepageActivity.class));
            }
            if(id == R.id.logout){
                Intent intent= new Intent(this, LoginActivity.class);
                startActivity(intent);
            }
            if(id == R.id.meinKonto){
                startActivity(new Intent(ShoppingListActivity.this, AccountActivity.class));
            }
            if(id == R.id.warenkorb){
                startActivity(new Intent(ShoppingListActivity.this, ShoppingListActivity.class));
            }
            if(id == R.id.meineBestellungen){
                //startActivity(new Intent(ShoppingListActivity.this, BestellungenActivity.class));
            }
        }catch(Exception ex){
            Toast.makeText(this,"error in Menu: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }

        return false;
    }
}

