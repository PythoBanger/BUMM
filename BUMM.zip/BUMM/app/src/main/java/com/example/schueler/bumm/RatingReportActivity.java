package com.example.schueler.bumm;

import android.annotation.*;
import android.content.*;
import android.provider.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import com.example.schueler.bumm.pkgData.*;

import java.util.*;

public class RatingReportActivity extends AppCompatActivity implements AdapterView.OnItemLongClickListener{
    ListView ReportsListView;
    Database db=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_report);
        try {
            db = Database.newInstance();
            initComponents();
            setListener();
            fillListWithReports();
        } catch (Exception ex) {
            Toast.makeText(this, "error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void initComponents() {
        ReportsListView = (ListView) findViewById(R.id.listVReports);;

    }
    private void setListener() throws Exception{
        ReportsListView.setOnItemLongClickListener(this);
    }

    private void fillListWithReports() throws Exception {
        ArrayAdapter<RatingReport> itemsAdapter =
                new ArrayAdapter<RatingReport>(this, android.R.layout.simple_list_item_1, db.getAllRatingReports());

        ReportsListView.setAdapter(itemsAdapter);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        final RatingReport rp = (RatingReport) parent.getItemAtPosition(position);

        new AlertDialog.Builder(RatingReportActivity.this)
                .setTitle("Artikel melden?")
                .setPositiveButton("RATING OK. ALLE REPORTS LÖSCHEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                try {
                                    db.deleteRatingReports(rp);
                                    fillListWithReports();
                                  dialog.cancel();
                                } catch (Exception ex) {
                                    Toast.makeText(RatingReportActivity.this, "err:" + ex, Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                .setNegativeButton("RATING LÖSCHEN",
                        new DialogInterface.OnClickListener() {
                            @TargetApi(11)
                            public void onClick(DialogInterface dialog, int id) {
                                try {
                                    db.deleteRating(rp.getReportedRating());
                                    fillListWithReports();
                                    dialog.cancel();
                                } catch (Exception ex) {
                                    Toast.makeText(RatingReportActivity.this, "err:" + ex, Toast.LENGTH_LONG).show();

                                }
                            }
                        }).show();
        return true;
    }
}
