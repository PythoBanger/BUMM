package com.example.schueler.bumm;

import static android.view.View.*;


import android.content.*;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.*;
import android.widget.*;
import com.example.schueler.bumm.pkgData.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btnLogin;
    private Button btnRegister;
    private TextView txtUName;
    private TextView txtPW;
    Database db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = Database.newInstance();
        db.setURL("http://192.168.1.16:28389/");
        //db.setURL("http://192.168.1.11:28389/");
       // db.setURL("http://192.168.196.169:28389/");

        try{
            initComponents();
            setListener();
        }catch (Exception ex){
            Toast.makeText(this,"Fail: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }

    }


    private void setListener() throws Exception{
        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
    }

    private void initComponents() throws Exception{
        btnLogin = (Button) findViewById(R.id.buttonLogin);
        btnRegister = (Button) findViewById(R.id.buttonRegestrieren);
        txtUName = (TextView) findViewById(R.id.txtUName);
        txtPW=(TextView) findViewById(R.id.txtPW);
    }



    @Override
    public void onClick(View view) {
        try{
            switch(view.getId()){
                case R.id.buttonLogin:{
                    String uname= txtUName.getText().toString();
                    String pw = txtPW.getText().toString();
                    if(uname.isEmpty() || pw.isEmpty()) //toDo: better checking......
                        throw new Exception("data cant be empty");

                    User loggedUser = db.loginUser(new User(uname,pw));
                    if(loggedUser.getRole().equals("customer")){
                        Intent intent =new Intent(this, HomepageActivity.class);
                        startActivity(intent);
                    }else{ //admin... toDo: implement
                        //Intent intent =new Intent(this, HomepageActivity.class);
                       // startActivity(intent);
                    }

                    break;
                }
                case R.id.buttonRegestrieren:{
                    startActivity(new Intent(LoginActivity.this, RegestrierenActivity.class));
                    break;
                }
            }

        }catch (Exception ex){
            Toast.makeText(this, "error: " + ex.getMessage(),Toast.LENGTH_LONG).show();
        }
    }


}
